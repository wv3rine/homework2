import java.util.ArrayList;

/**
 * Интефейс, имитирующий поведение вершины в ориентированном графе
 * (с помощью методов getKey и getDependenciesKeys).
 * @param <T> тип ключа в вершине.
 * */
interface Verticable<T> {
    T getKey();
    ArrayList<T> getDependenciesKeys();
}