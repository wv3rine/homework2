import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {
    private static final String rootDirectoryPath = "Root";

    public static void main(String[] args) {
        DirectoryHandler directoryHandler = new DirectoryHandler(rootDirectoryPath);
        try {
            directoryHandler.processFilesFromFolder(rootDirectoryPath);
            if (!directoryHandler.isNoCycles()) {
                System.out.println("Ошибка! Обнаружена циклическая зависимость, перезапустите программу с изменениями.");
                return;
            }
            directoryHandler.makeConcatenationFile();

        } catch (SecurityException e) {
            System.out.println(e.getMessage() + " - сообщение об ошибке. Проблемы с Security Manager" +
                    ", перезапустите программу с изменениями.\n");
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage() + " - сообщение об ошибке. Файл не найден" +
                    ", перезапустите программу с изменениями.\n");
        } catch (IOException e) {
            System.out.println(e.getMessage() + " - сообщение об ошибке. Ошибка чтения/записи" +
                    ", перезапустите программу с изменениями.\n");
        }

    }
}