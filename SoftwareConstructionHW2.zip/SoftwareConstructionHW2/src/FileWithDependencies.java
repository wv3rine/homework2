import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Класс, наследованный от {@link File}. При создании
 * объекта ищет связи данного файла с другими (посредством
 * команды "require filePath" внутри файла)
 * */
public class FileWithDependencies extends File implements Verticable<String> {
    private static final String REQUIRING_REGEX = "^require '.*'$";
    private static final String PATH_REGEX = "'.*'$";
    private static final String SEPARATOR = File.separator;
    private ArrayList<String> dependenciesPaths;

    public FileWithDependencies(String pathname) throws IOException {
        super(pathname);
        this.initializeDependencies();
    }

    public ArrayList<String> getDependenciesPaths() {
        return dependenciesPaths;
    }

    /**
     * Инициализирует связи у файла.
     * @exception FileNotFoundException, если файл (или связанные файлы) не найден (не найдены).
     * @exception IOException, если произошла ошибка со считыванием.
     * */
    private void initializeDependencies() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(this));
        String line = reader.readLine();
        String possiblePath = lineIsRequiring(line);
        while (line != null) {
            if (possiblePath != null) {
                dependenciesPaths.add(possiblePath);
            }
            line = reader.readLine();
            possiblePath = lineIsRequiring(line);
        }
    }

    /**
     * Получает содержимое файла без команд типа "require filePath".
     * @exception IOException, если произошла ошибка со считыванием.
     * @return содержимое файла в формате списка строк.
     * */
    public ArrayList<String> getContent() throws IOException {
        ArrayList<String> content = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(this));
        String line = reader.readLine();
        while (line != null) {
            if (lineIsRequiring(line) == null) {
                content.add(line);
            }
            line = reader.readLine();
        }
        return content;
    }

    /**
     *  Проверяет, является ли строка командой типа "require filePath", и возвращает
     *  null, если не является, filePath иначе.
     *  @param line строка, которую необходимо проверить.
     *  @return null, если строка не является командой типа "require filePath", filePath иначе.
     * */
    private static String lineIsRequiring(String line) {
        Pattern pattern = Pattern.compile(REQUIRING_REGEX);
        Matcher matcher = pattern.matcher(line);
        if (!matcher.matches()) {
            return null;
        }

        pattern = Pattern.compile(PATH_REGEX);
        matcher = pattern.matcher(line);
        return matcher.find() ? line.substring(matcher.start() + 1, matcher.end() - 1) : null;
    }

    @Override
    public String getKey() {
        return getPath();
    }

    @Override
    public ArrayList<String> getDependenciesKeys() {
        return dependenciesPaths;
    }
}
