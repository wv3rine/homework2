import java.util.ArrayList;
import java.util.HashMap;

/**
 * Класс ориентированного графа.
 * @param <T> тип ключа вершины.
 * @param <V> тип вершины, реализующий интерфейс {@link Verticable<T>}.
 * */
public class Graph<T, V extends Verticable<T>> {
    private HashMap<T, ArrayList<T>> graph;
    private HashMap<T, Color> color;
    public void Add(V vertex) {
        graph.put(vertex.getKey(), vertex.getDependenciesKeys());
    }

    public boolean isAcyclic() {
        // Перекраска вершин графа в белый цвет.
        for (T key : graph.keySet()) {
            color.put(key, Color.WHITE);
        }

        for (T key : graph.keySet()) {
            if (dfs(key)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Обход в глубину графа, начиная с указанной вершины.
     * @param key ключ вершины, с которой начинается обход.
     * @return true, если вершина учавствует в цикле; false иначе.
     * */
    private boolean dfs(T key) {
        if (color.get(key) == Color.BLACK) {
            return false;
        }

        color.put(key, Color.GREY);
        for (T adjacentVertex : graph.get(key)) {
            if (color.get(adjacentVertex) == Color.WHITE) {
                dfs(adjacentVertex);
            } else if (color.get(adjacentVertex) == Color.GREY) {
                return true;
            }
        }
        color.put(key, Color.BLACK);
        return false;
    }

    private enum Color {
        WHITE,
        GREY,
        BLACK
    }

    // Вообще вопрос, насколько это нормальный стиль для программирования -
    // когда один в коде нужно буквально добавить одну строчку для разных функций,
    // делать такое перечисление, как бы улучшенный флаг?
    /**
     * Перечисление, необходимое для обозначения режима dfs;
     * CHECK_CYCLES, если нужно отыскать циклы; GET_TOPOLOGICAL_SORT_CONTENT,
     * если нужно найти сконкатенировать содержания вершин в порядке топологической
     * сортировки.
     * */
    private enum Mode {
        CHECK_CYCLES,
        GET_TOPOLOGICAL_SORT_CONTENT
    }
}