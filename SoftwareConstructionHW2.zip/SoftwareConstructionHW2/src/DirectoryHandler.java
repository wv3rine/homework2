import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Класс, обрабатывающий указанную директорию. Основной функционал -
 * найти все файлы в директории и поддиректориях любой вложенности и
 * найти связи между файлами (согласно команде "require filePath").
 * */
public class DirectoryHandler {
    /**
     * Граф связей.
     * */
    private Graph<String, FileWithDependencies> graph;
    private final String rootDirectoryPath;

    private final String concatenationFilePath;
    DirectoryHandler(String rootDirectoryPath) {
        this.rootDirectoryPath = rootDirectoryPath;
        this.concatenationFilePath = rootDirectoryPath + File.separator + "answerFile.txt";
    }

    /**
     * Обходит в глубину указанную, находит связи между файлами
     * в ней и заполняет граф связей.
     * @param directoryPath корневая папка.
     * @exception IOException, если возникла проблема с вводом.
     * @exception SecurityException, если Sequirity Manager не позволяет прочитать файл.
     * */
    public void processFilesFromFolder(String directoryPath) throws IOException, SecurityException {
        File directory = new File(directoryPath);
        if (!directory.isDirectory()) {
            return;
        }

        File[] filesAndDirectories = directory.listFiles();
        if (filesAndDirectories == null) {
            return;
        }
        for (File fileOrDirectory : filesAndDirectories) {
            if (fileOrDirectory.isDirectory()) {
                processFilesFromFolder(fileOrDirectory.getPath());
            } else {
                graph.Add(new FileWithDependencies(fileOrDirectory.getPath()));
            }
        }
    }

    /**
     * Создает файл, состоящий из конкатенаций всех файлов в директории
     * согласно следующему правилу: если A require B, то содержимое A
     * находится выше содержимого B.
     * @exception IOException, если возникла проблема с вводом.
     * @exception SecurityException, если Sequirity Manager не позволяет прочитать файл.
     * */
    void makeConcatenationFile() throws IOException, SecurityException {
        File concatenationFile = new File(concatenationFilePath);
        // Странный костыль, но как-то другого метода пока не нашел
        if (!concatenationFile.createNewFile()) {
            concatenationFile.delete();
            concatenationFile.createNewFile();
        }


    }

    boolean isNoCycles() {
        return graph.isAcyclic();
    }
}
